INSERT INTO `produtos` (SKU, nome, descricao, preco, cor, tamanho, genero, quantidade, imagem) VALUES ('camisetaazulmasc', 'Camiseta Azul', 'Camiseta azul masculina básica', 79, 'azul', 'M', 'Masculino', 10, './images/camiseta-azul.jpg');
INSERT INTO `produtos` (SKU, nome, descricao, preco, cor, tamanho, genero, quantidade, imagem) VALUES ('camisetabrancamasc', 'Camiseta Branca', 'Camiseta branca masculina básica', 59, 'branca', 'P', 'Masculino', 7, './images/camiseta-branca.webp');
INSERT INTO `produtos` (SKU, nome, descricao, preco, cor, tamanho, genero, quantidade, imagem) VALUES ('camisetacinzamasc', 'Camiseta Cinza', 'Camiseta cinza masculina básica', 69, 'azul', 'G', 'Masculino', 8, './images/camiseta-cinza.webp');
INSERT INTO `produtos` (SKU, nome, descricao, preco, cor, tamanho, genero, quantidade, imagem) VALUES ('camisetaazulmasc', 'Camiseta Azul', 'Camiseta azul masculina básica', 79, 'azul', 'P', 'Masculino', 0, './images/camiseta-azul.jpg');
INSERT INTO `produtos` (SKU, nome, descricao, preco, cor, tamanho, genero, quantidade, imagem) VALUES ('camisetabrancafem', 'Camiseta Branca Feminina', 'Camiseta branca feminina básica', 59, 'branca', 'P', 'Feminino', 0, './images/camiseta-feminina.jpg');

INSERT INTO `usuarios` (nome, sobrenome, email, data_nascimento, sexo, cpf, telefone, senha, confirma_senha, promocoes) VALUES ('Pedro', 'Shiroma', 'pedro@ohquemfala.com.br', '1990-08-06', 'Masculino', '33333333333', '15999999999', '123456', '123456', '1');
INSERT INTO `usuarios` (nome, sobrenome, email, data_nascimento, sexo, cpf, telefone, senha, confirma_senha, promocoes) VALUES ('Pedro', 'Maravelli', 'pedro@dh.com.br', '2006-11-05', 'Masculino', '33333333335', '15999999998', '123456', '123456', '1');
INSERT INTO `usuarios` (nome, sobrenome, email, data_nascimento, sexo, cpf, telefone, senha, confirma_senha, promocoes) VALUES ('Bruno', 'Ariel', 'bruno@dh.com.br', '2000-11-05', 'Masculino', '33333333334', '15999999997', '123456', '123456', '0');

INSERT INTO `carrinhos` (status, usuarios_id) VALUES ('Aberto', 1);
INSERT INTO `carrinhos` (status, usuarios_id) VALUES ('Fechado', 2);
INSERT INTO `carrinhos` (status, usuarios_id) VALUES ('Fechado', 3);

INSERT INTO `carrinhos_has_produtos` (carrinhos_id, produtos_id, quantidade) VALUES (1, 1, 1);
INSERT INTO `carrinhos_has_produtos` (carrinhos_id, produtos_id, quantidade) VALUES (1, 2, 2);
INSERT INTO `carrinhos_has_produtos` (carrinhos_id, produtos_id, quantidade) VALUES (1, 3, 3);


INSERT INTO `enderecos` (pais, estado, cidade, rua, numero, complemento, cep, usuarios_id) VALUES ('Brasil', 'SP', 'São Paulo', 'R Major Sertorio', '120','', '05874000', 1);
INSERT INTO `enderecos` (pais, estado, cidade, rua, numero, complemento, cep, usuarios_id) VALUES ('Brasil', 'SP', 'São Paulo', 'Av Mateo Bei', '140', 'B 1 AP 12', '08374000', 2);
INSERT INTO `enderecos` (pais, estado, cidade, rua, numero, complemento, cep, usuarios_id) VALUES ('Brasil', 'SP', 'São Paulo', 'Av Joao Dias', '674','', '04756000', 3);




